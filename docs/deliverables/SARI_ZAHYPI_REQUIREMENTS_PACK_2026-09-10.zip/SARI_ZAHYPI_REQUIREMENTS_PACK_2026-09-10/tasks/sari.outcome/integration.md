# Integration: sari.outcome

- **المسار الحالي:** planned — غير منفذ
- **المسار المتخصص المقترح:** /v1/sari/outcome
- **المشروع:** sari
- **Tenant header:** X-ZahyPi-Tenant = merchant:<trusted-id>
- **Task header:** X-Task-Type = sari.outcome
- **Idempotency:** مفتاح واحد للعملية الواحدة ويعاد استخدامه فقط عند retry لنفس body.
- **النجاح:** لا يقبل دون trace_id وrun_manifest_id ومخرج مطابق للـschema.
- **التراجع:** queue_outcome_for_retry. لا يوجد fallback تلقائي للبيانات الحمراء.

## مصادر الكود

- `planned: ZahyPi specialized endpoint /v1/sari/outcome`
