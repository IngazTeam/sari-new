# Integration: sari.order.zid-extract

- **المسار الحالي:** /v1/jobs
- **المسار المتخصص المقترح:** /v1/jobs
- **المشروع:** sari
- **Tenant header:** X-ZahyPi-Tenant = merchant:<trusted-id>
- **Task header:** X-Task-Type = sari.order.zid-extract
- **Idempotency:** مفتاح واحد للعملية الواحدة ويعاد استخدامه فقط عند retry لنفس body.
- **النجاح:** لا يقبل دون trace_id وrun_manifest_id ومخرج مطابق للـschema.
- **التراجع:** require_manual_zid_order_confirmation. لا يوجد fallback تلقائي للبيانات الحمراء.

## مصادر الكود

- `server/automation/zid-order-from-chat.ts`
