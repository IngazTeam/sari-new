# Integration: sari.webhook.merchant-reply-improvement

- **المسار الحالي:** /v1/jobs
- **المسار المتخصص المقترح:** /v1/jobs
- **المشروع:** sari
- **Tenant header:** X-ZahyPi-Tenant = merchant:<trusted-id>
- **Task header:** X-Task-Type = sari.webhook.merchant-reply-improvement
- **Idempotency:** مفتاح واحد للعملية الواحدة ويعاد استخدامه فقط عند retry لنفس body.
- **النجاح:** لا يقبل دون trace_id وrun_manifest_id ومخرج مطابق للـschema.
- **التراجع:** retain_original_merchant_reply. لا يوجد fallback تلقائي للبيانات الحمراء.

## مصادر الكود

- `server/webhooks/greenapi.ts`
