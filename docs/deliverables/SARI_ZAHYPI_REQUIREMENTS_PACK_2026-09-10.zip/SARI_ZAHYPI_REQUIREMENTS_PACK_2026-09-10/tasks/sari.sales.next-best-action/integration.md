# Integration: sari.sales.next-best-action

- **المسار الحالي:** /v1/jobs
- **المسار المتخصص المقترح:** /v1/sari/next-action
- **المشروع:** sari
- **Tenant header:** X-ZahyPi-Tenant = merchant:<trusted-id>
- **Task header:** X-Task-Type = sari.sales.next-best-action
- **Idempotency:** مفتاح واحد للعملية الواحدة ويعاد استخدامه فقط عند retry لنفس body.
- **النجاح:** لا يقبل دون trace_id وrun_manifest_id ومخرج مطابق للـschema.
- **التراجع:** request_human_decision. لا يوجد fallback تلقائي للبيانات الحمراء.

## مصادر الكود

- `server/ai/action-selector.ts`
