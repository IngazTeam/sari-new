# Integration: sari.reply

- **المسار الحالي:** /v1/jobs
- **المسار المتخصص المقترح:** /v1/sari/reply
- **المشروع:** sari
- **Tenant header:** X-ZahyPi-Tenant = merchant:<trusted-id>
- **Task header:** X-Task-Type = sari.reply
- **Idempotency:** مفتاح واحد للعملية الواحدة ويعاد استخدامه فقط عند retry لنفس body.
- **النجاح:** لا يقبل دون trace_id وrun_manifest_id ومخرج مطابق للـschema.
- **التراجع:** continue_without_automatic_reply. لا يوجد fallback تلقائي للبيانات الحمراء.

## مصادر الكود

- `server/ai/sari-personality.ts`
- `server/ai/openai.ts`
