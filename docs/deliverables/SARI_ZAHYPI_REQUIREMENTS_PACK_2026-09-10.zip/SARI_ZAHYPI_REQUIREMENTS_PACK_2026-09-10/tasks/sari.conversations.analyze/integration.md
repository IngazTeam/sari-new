# Integration: sari.conversations.analyze

- **المسار الحالي:** planned — غير منفذ
- **المسار المتخصص المقترح:** /v1/sari/conversations/analyze
- **المشروع:** sari
- **Tenant header:** X-ZahyPi-Tenant = merchant:<trusted-id>
- **Task header:** X-Task-Type = sari.conversations.analyze
- **Idempotency:** مفتاح واحد للعملية الواحدة ويعاد استخدامه فقط عند retry لنفس body.
- **النجاح:** لا يقبل دون trace_id وrun_manifest_id ومخرج مطابق للـschema.
- **التراجع:** continue_live_chat_without_analysis. لا يوجد fallback تلقائي للبيانات الحمراء.

## مصادر الكود

- `planned: ZahyPi specialized endpoint /v1/sari/conversations/analyze`
