# Integration: sari.customer.profile-enrichment

- **المسار الحالي:** /v1/jobs
- **المسار المتخصص المقترح:** /v1/jobs
- **المشروع:** sari
- **Tenant header:** X-ZahyPi-Tenant = merchant:<trusted-id>
- **Task header:** X-Task-Type = sari.customer.profile-enrichment
- **Idempotency:** مفتاح واحد للعملية الواحدة ويعاد استخدامه فقط عند retry لنفس body.
- **النجاح:** لا يقبل دون trace_id وrun_manifest_id ومخرج مطابق للـschema.
- **التراجع:** retain_current_customer_profile. لا يوجد fallback تلقائي للبيانات الحمراء.

## مصادر الكود

- `server/ai/profile-enrichment.ts`
