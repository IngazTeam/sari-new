# Integration: sari.webhook.merchant-reply-feedback

- **المسار الحالي:** /v1/jobs
- **المسار المتخصص المقترح:** /v1/jobs
- **المشروع:** sari
- **Tenant header:** X-ZahyPi-Tenant = merchant:<trusted-id>
- **Task header:** X-Task-Type = sari.webhook.merchant-reply-feedback
- **Idempotency:** مفتاح واحد للعملية الواحدة ويعاد استخدامه فقط عند retry لنفس body.
- **النجاح:** لا يقبل دون trace_id وrun_manifest_id ومخرج مطابق للـschema.
- **التراجع:** continue_without_feedback_analysis. لا يوجد fallback تلقائي للبيانات الحمراء.

## مصادر الكود

- `server/webhooks/greenapi.ts`
