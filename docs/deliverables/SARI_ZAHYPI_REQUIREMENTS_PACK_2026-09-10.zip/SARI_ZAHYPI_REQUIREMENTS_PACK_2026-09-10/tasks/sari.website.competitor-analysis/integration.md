# Integration: sari.website.competitor-analysis

- **المسار الحالي:** /v1/jobs
- **المسار المتخصص المقترح:** /v1/jobs
- **المشروع:** sari
- **Tenant header:** X-ZahyPi-Tenant = merchant:<trusted-id>
- **Task header:** X-Task-Type = sari.website.competitor-analysis
- **Idempotency:** مفتاح واحد للعملية الواحدة ويعاد استخدامه فقط عند retry لنفس body.
- **النجاح:** لا يقبل دون trace_id وrun_manifest_id ومخرج مطابق للـschema.
- **التراجع:** continue_without_competitor_summary. لا يوجد fallback تلقائي للبيانات الحمراء.

## مصادر الكود

- `server/_core/websiteAnalyzer.ts`
