# خريطة كود قابلة للمراجعة

| المهمة | المصادر والأسطر/الدوال | المسار الحالي |
|---|---|---|
| sari.reply | server/ai/sari-personality.ts:1585<br>server/ai/sari-personality.ts:1621<br>server/ai/sari-personality.ts:2331<br>server/ai/sari-personality.ts:2847<br>server/ai/sari-personality.ts:3049<br>server/ai/openai.ts:169 | /v1/jobs |
| sari.welcome | server/ai/sari-personality.ts:3157 | /v1/jobs |
| sari.supervisor.recovery | server/ai/supervisor-recovery.ts:127 | /v1/jobs |
| sari.product.search | server/ai/product-intelligence.ts:110 | /v1/jobs |
| sari.product.suggestions | server/ai/product-intelligence.ts:186 | /v1/jobs |
| sari.sentiment.weekly | server/ai/weekly-sentiment.ts:83 | /v1/jobs |
| sari.sentiment | server/ai/sentiment-analysis.ts:66 | /v1/jobs |
| sari.keyword.quick-responses | server/ai/keyword-analysis.ts:219 | /v1/jobs |
| sari.knowledge.classify | server/ai/knowledge-engine.ts:115 | /v1/jobs |
| sari.knowledge.sales-intelligence | server/ai/knowledge-engine.ts:207 | /v1/jobs |
| sari.knowledge.evolution | server/ai/knowledge-engine.ts:453 | /v1/jobs |
| sari.keyword.extraction | server/ai/keyword-extraction.ts:59 | /v1/jobs |
| sari.insights | server/ai/insights.ts:233 | /v1/jobs |
| sari.sales.next-best-action | server/ai/action-selector.ts:155 | /v1/jobs |
| sari.merchant.intent | server/ai/merchant-mode.ts:149 | /v1/jobs |
| sari.merchant.reply-coaching | server/ai/merchant-mode.ts:335 | /v1/jobs |
| sari.merchant.assistant | server/ai/merchant-mode.ts:616 | /v1/jobs |
| sari.learning.pattern-analysis | server/ai/learning-engine.ts:334 | /v1/jobs |
| sari.webhook.merchant-reply-improvement | server/webhooks/greenapi.ts:708 | /v1/jobs |
| sari.webhook.merchant-reply-feedback | server/webhooks/greenapi.ts:873 | /v1/jobs |
| sari.knowledge.profile-analysis | server/_core/index.ts:397 | /v1/jobs |
| sari.knowledge.content-analysis | server/routers-sari-brain.ts:847 | /v1/jobs |
| sari.website.catalog-extraction | server/_core/websiteAnalyzer.ts:1558 | /v1/jobs |
| sari.website.insights | server/_core/websiteAnalyzer.ts:2442 | /v1/jobs |
| sari.website.industry | server/_core/websiteAnalyzer.ts:2547 | /v1/jobs |
| sari.website.competitor-analysis | server/_core/websiteAnalyzer.ts:2598 | /v1/jobs |
| sari.website.full-extraction | server/_core/websiteAnalyzer.ts:2771 | /v1/jobs |
| sari.website.content-classification | server/routers-sari-brain.ts:1500 | /v1/jobs |
| sari.booking.extract | server/ai.ts:699 | /v1/jobs |
| sari.booking.service-match | server/ai.ts:767 | /v1/jobs |
| sari.appointment.extract | server/appointmentBot.ts:85 | /v1/jobs |
| sari.order.extract | server/automation/order-from-chat.ts:76 | /v1/jobs |
| sari.order.zid-extract | server/automation/zid-order-from-chat.ts:64 | /v1/jobs |
| sari.catalog.file-sales-analysis | server/routers-products.ts:973 | /v1/jobs |
| sari.catalog.file-extraction | server/routers-products.ts:1182 | /v1/jobs |
| sari.product.selection | server/ai/product-intelligence.ts:290 | /v1/jobs |
| sari.keyword.frequent-questions | server/ai/keyword-analysis.ts:105 | /v1/jobs |
| sari.customer.profile-enrichment | server/ai/profile-enrichment.ts:158 | /v1/jobs |
| sari.customer.intent | server/ai/sari-personality.ts:3203 | /v1/jobs |
| sari.conversation.topic-change | server/ai/sari-personality.ts:570 | /v1/jobs |
| sari.response.critique | server/ai/response-critic.ts:152 | /v1/jobs |
| sari.response.rewrite | server/ai/response-critic.ts:234 | /v1/jobs |
| sari.response.validate | server/ai/response-validator.ts:418 | /v1/jobs |
| sari.response.correct | server/ai/response-validator.ts:511 | /v1/jobs |
| sari.reply.suggestions | server/routers-ai-suggestions.ts:91 | /v1/jobs |
| sari.reply.custom | server/routers-ai-suggestions.ts:191 | /v1/jobs |
| sari.reply.improve | server/routers-ai-suggestions.ts:245 | /v1/jobs |
| sari.platform.health | server/routers-ai-settings.ts:193 | /v1/jobs |
| sari.conversations.analyze | planned | غير منفذ |
| sari.outcome | planned | غير منفذ |

المزود → assertSariTaskPayload(output) → caller الذي يملك الآثار الجانبية. الجداول/permission لكل caller تحتاج استكمال الجرد؛ لا نخمن Model/Table.
