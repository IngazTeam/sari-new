# حدود البيانات والأمن

| مجموعة الحقول | المصدر/الحساسية | الحد والقرار |
|---|---|---|
| operationId / traceId | معرّف تنفيذ خادمي؛ ليس صلاحية | مقيدان بالمخطط ويرتبط traceId بالطلب |
| conversationId / subjectId | غلاف توافق مشتق من merchant؛ لا يثبت ملكية سجل CRM | يلزم إثبات ملكية caller قبل تضمين سياقه |
| message / messages / promptMessages / facts / query | محتوى caller وقد يحوي PII | bounds من schema؛ لا ينشر في سجل الأدلة |
| summaries / objective / notes | مشتقات نصية قد تحوي PII | نفس سياسة أصل المحادثة |
| productIds / referenceIds / allowedLabels / constraints | سياق كتالوج أو مراجع، لا تفويض | تحقق server-side؛ الغلاف الحالي لا يجلب السجلات بهذه المعرفات |
| actionId / outcome | planned؛ مصدر الحقيقة لم يعتمد | لا تدريب ولا أثر تجاري تلقائي |
| applicationResponse / text / findings / action / labels | مخرج نموذج غير موثوق حتى التحقق | schema ثم parser وحواجز caller؛ ليس تفويض دفع أو خصم |

سياسة كل مهمة في الكتالوج: data_classification وexternal_processing. بيانات المحادثة red/deny افتراضيًا؛ لا fallback خارجي تلقائي. اعتماد استثناءات الصوت/embeddings والاحتفاظ والحذف والتشفير عند التخزين وموافقة العميل: UNKNOWN — OWNER_DECISION_REQUIRED. HTTPS وتشفير اعتماد الموصل لا يثبتان وحدهما تشفير كل محتوى المحادثات.

حظر البطاقات وكلمات المرور وOTP في مدخل النموذج شرط مطلوب؛ هذه الحزمة لا تثبت وجود DLP شامل أو اجتياز بيانات حقيقية لهذه السياسة. يلزم اختبار تنقيح مستقل قبل التوسع.
