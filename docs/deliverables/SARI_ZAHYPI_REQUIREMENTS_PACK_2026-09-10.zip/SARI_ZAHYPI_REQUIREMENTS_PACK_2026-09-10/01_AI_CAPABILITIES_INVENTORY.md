# الجرد المرتبط بالمصدر

التفاصيل غير المثبتة معلّمة صراحة؛ لا يعد الملف جرد UI/صلاحيات معتمدًا.

## sari.reply

- القدرة: صياغة رد المحادثة; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-conversation-team.
- Source/Prompt references: server/ai/sari-personality.ts:1585, server/ai/sari-personality.ts:1621, server/ai/sari-personality.ts:2331, server/ai/sari-personality.ts:2847, server/ai/sari-personality.ts:3049, server/ai/openai.ts:169.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: false; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: continue_without_automatic_reply; timeout: 25000 ms.

## sari.welcome

- القدرة: صياغة رسالة الترحيب; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-conversation-team.
- Source/Prompt references: server/ai/sari-personality.ts:3157.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: false; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: use_static_welcome; timeout: 20000 ms.

## sari.supervisor.recovery

- القدرة: استعادة المحادثة تحت إشراف النظام; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-conversation-team.
- Source/Prompt references: server/ai/supervisor-recovery.ts:127.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: true; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: escalate_to_human; timeout: 25000 ms.

## sari.product.search

- القدرة: البحث الذكي في المنتجات; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-commerce-team.
- Source/Prompt references: server/ai/product-intelligence.ts:110.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: false; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: use_deterministic_catalog_search; timeout: 20000 ms.

## sari.product.suggestions

- القدرة: اقتراح المنتجات; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-commerce-team.
- Source/Prompt references: server/ai/product-intelligence.ts:186.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: false; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: show_ranked_catalog_results; timeout: 20000 ms.

## sari.sentiment.weekly

- القدرة: تحليل المشاعر الأسبوعي; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-insights-team.
- Source/Prompt references: server/ai/weekly-sentiment.ts:83.
- التنفيذ: async; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: false; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: retain_previous_weekly_summary; timeout: 60000 ms.

## sari.sentiment

- القدرة: تحليل مشاعر الرسالة; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-insights-team.
- Source/Prompt references: server/ai/sentiment-analysis.ts:66.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: false; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: mark_sentiment_unknown; timeout: 15000 ms.

## sari.keyword.quick-responses

- القدرة: اقتراح الردود السريعة; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-conversation-team.
- Source/Prompt references: server/ai/keyword-analysis.ts:219.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: true; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: show_no_quick_response; timeout: 20000 ms.

## sari.knowledge.classify

- القدرة: تصنيف المعرفة; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-knowledge-team.
- Source/Prompt references: server/ai/knowledge-engine.ts:115.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: false; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: leave_item_unclassified; timeout: 20000 ms.

## sari.knowledge.sales-intelligence

- القدرة: استخراج ذكاء المبيعات من المعرفة; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-knowledge-team.
- Source/Prompt references: server/ai/knowledge-engine.ts:207.
- التنفيذ: async; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: true; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: retain_source_knowledge; timeout: 60000 ms.

## sari.knowledge.evolution

- القدرة: تطوير قاعدة المعرفة; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-knowledge-team.
- Source/Prompt references: server/ai/knowledge-engine.ts:453.
- التنفيذ: async; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: true; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: do_not_change_knowledge; timeout: 60000 ms.

## sari.keyword.extraction

- القدرة: استخراج الكلمات المفتاحية; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-insights-team.
- Source/Prompt references: server/ai/keyword-extraction.ts:59.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: false; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: return_empty_keywords; timeout: 15000 ms.

## sari.insights

- القدرة: استخراج رؤى المحادثة; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-insights-team.
- Source/Prompt references: server/ai/insights.ts:233.
- التنفيذ: async; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: false; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: continue_without_new_insights; timeout: 60000 ms.

## sari.sales.next-best-action

- القدرة: اختيار أفضل إجراء تالٍ; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-sales-team.
- Source/Prompt references: server/ai/action-selector.ts:155.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: true; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: request_human_decision; timeout: 25000 ms.

## sari.merchant.intent

- القدرة: تصنيف نية التاجر; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-merchant-team.
- Source/Prompt references: server/ai/merchant-mode.ts:149.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: false; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: mark_intent_unknown; timeout: 15000 ms.

## sari.merchant.reply-coaching

- القدرة: تدريب التاجر على الرد; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-merchant-team.
- Source/Prompt references: server/ai/merchant-mode.ts:335.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: true; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: show_no_coaching; timeout: 20000 ms.

## sari.merchant.assistant

- القدرة: مساعد التاجر; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-merchant-team.
- Source/Prompt references: server/ai/merchant-mode.ts:616.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: true; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: continue_without_assistant; timeout: 25000 ms.

## sari.learning.pattern-analysis

- القدرة: تحليل أنماط التعلم; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-learning-team.
- Source/Prompt references: server/ai/learning-engine.ts:334.
- التنفيذ: async; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: true; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: retain_current_learning_state; timeout: 60000 ms.

## sari.webhook.merchant-reply-improvement

- القدرة: تحسين رد التاجر من الويب هوك; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-channel-team.
- Source/Prompt references: server/webhooks/greenapi.ts:708.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: true; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: retain_original_merchant_reply; timeout: 20000 ms.

## sari.webhook.merchant-reply-feedback

- القدرة: تحليل ملاحظات رد التاجر; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-channel-team.
- Source/Prompt references: server/webhooks/greenapi.ts:873.
- التنفيذ: async; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: false; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: continue_without_feedback_analysis; timeout: 60000 ms.

## sari.knowledge.profile-analysis

- القدرة: تحليل ملف التاجر المعرفي; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-knowledge-team.
- Source/Prompt references: server/_core/index.ts:397.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: true; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: retain_extracted_profile_text; timeout: 25000 ms.

## sari.knowledge.content-analysis

- القدرة: تحليل محتوى قاعدة المعرفة; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-knowledge-team.
- Source/Prompt references: server/routers-sari-brain.ts:847.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: true; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: require_manual_content_review; timeout: 25000 ms.

## sari.website.catalog-extraction

- القدرة: استخراج كتالوج الموقع; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-onboarding-team.
- Source/Prompt references: server/_core/websiteAnalyzer.ts:1558.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: false; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: retain_html_extracted_catalog; timeout: 25000 ms.

## sari.website.insights

- القدرة: توليد رؤى الموقع; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-onboarding-team.
- Source/Prompt references: server/_core/websiteAnalyzer.ts:2442.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: false; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: show_deterministic_site_metrics; timeout: 25000 ms.

## sari.website.industry

- القدرة: تصنيف مجال الموقع; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-onboarding-team.
- Source/Prompt references: server/_core/websiteAnalyzer.ts:2547.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: false; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: mark_industry_unknown; timeout: 25000 ms.

## sari.website.competitor-analysis

- القدرة: تحليل منافسي الموقع; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-onboarding-team.
- Source/Prompt references: server/_core/websiteAnalyzer.ts:2598.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: true; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: continue_without_competitor_summary; timeout: 25000 ms.

## sari.website.full-extraction

- القدرة: الاستخراج الكامل لمحتوى الموقع; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-onboarding-team.
- Source/Prompt references: server/_core/websiteAnalyzer.ts:2771.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: false; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: retain_deterministic_site_extraction; timeout: 25000 ms.

## sari.website.content-classification

- القدرة: تصنيف محتوى صفحة الموقع; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-onboarding-team.
- Source/Prompt references: server/routers-sari-brain.ts:1500.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: false; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: require_manual_page_classification; timeout: 25000 ms.

## sari.booking.extract

- القدرة: استخراج بيانات الحجز; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-booking-team.
- Source/Prompt references: server/ai.ts:699.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: false; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: request_missing_booking_fields; timeout: 25000 ms.

## sari.booking.service-match

- القدرة: مطابقة طلب الحجز بالخدمة; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-booking-team.
- Source/Prompt references: server/ai.ts:767.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: false; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: require_manual_service_selection; timeout: 25000 ms.

## sari.appointment.extract

- القدرة: استخراج تفاصيل الموعد; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-booking-team.
- Source/Prompt references: server/appointmentBot.ts:85.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: false; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: request_missing_appointment_fields; timeout: 25000 ms.

## sari.order.extract

- القدرة: استخراج الطلب من المحادثة; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-commerce-team.
- Source/Prompt references: server/automation/order-from-chat.ts:76.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: true; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: require_manual_order_confirmation; timeout: 25000 ms.

## sari.order.zid-extract

- القدرة: استخراج طلب زد من المحادثة; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-commerce-team.
- Source/Prompt references: server/automation/zid-order-from-chat.ts:64.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: true; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: require_manual_zid_order_confirmation; timeout: 25000 ms.

## sari.catalog.file-sales-analysis

- القدرة: تحليل ملف الكتالوج للمبيعات; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-commerce-team.
- Source/Prompt references: server/routers-products.ts:973.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: true; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: retain_imported_catalog_rows; timeout: 25000 ms.

## sari.catalog.file-extraction

- القدرة: استخراج عناصر ملف الكتالوج; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-commerce-team.
- Source/Prompt references: server/routers-products.ts:1182.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: true; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: require_manual_catalog_mapping; timeout: 25000 ms.

## sari.product.selection

- القدرة: تحديد المنتج المختار; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-commerce-team.
- Source/Prompt references: server/ai/product-intelligence.ts:290.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: false; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: request_product_clarification; timeout: 25000 ms.

## sari.keyword.frequent-questions

- القدرة: تحليل الأسئلة المتكررة; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-insights-team.
- Source/Prompt references: server/ai/keyword-analysis.ts:105.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: false; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: retain_existing_keyword_counts; timeout: 25000 ms.

## sari.customer.profile-enrichment

- القدرة: إثراء ملف العميل; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-insights-team.
- Source/Prompt references: server/ai/profile-enrichment.ts:158.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: false; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: retain_current_customer_profile; timeout: 25000 ms.

## sari.customer.intent

- القدرة: تحليل نية العميل; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-conversation-team.
- Source/Prompt references: server/ai/sari-personality.ts:3203.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: false; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: mark_customer_intent_unknown; timeout: 25000 ms.

## sari.conversation.topic-change

- القدرة: اكتشاف تغير موضوع المحادثة; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-conversation-team.
- Source/Prompt references: server/ai/sari-personality.ts:570.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: false; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: treat_as_same_topic; timeout: 25000 ms.

## sari.response.critique

- القدرة: تقييم جودة الرد; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-quality-team.
- Source/Prompt references: server/ai/response-critic.ts:152.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: false; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: pass_through_original_response; timeout: 25000 ms.

## sari.response.rewrite

- القدرة: إعادة صياغة الرد; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-quality-team.
- Source/Prompt references: server/ai/response-critic.ts:234.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: false; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: use_original_response; timeout: 25000 ms.

## sari.response.validate

- القدرة: التحقق الدلالي من الرد; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-quality-team.
- Source/Prompt references: server/ai/response-validator.ts:418.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: false; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: apply_deterministic_validation_only; timeout: 25000 ms.

## sari.response.correct

- القدرة: تصحيح الرد غير المطابق; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-quality-team.
- Source/Prompt references: server/ai/response-validator.ts:511.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: false; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: use_sanitized_original_response; timeout: 25000 ms.

## sari.reply.suggestions

- القدرة: اقتراح ردود للمحادثة; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-conversation-team.
- Source/Prompt references: server/routers-ai-suggestions.ts:91.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: true; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: show_no_reply_suggestions; timeout: 25000 ms.

## sari.reply.custom

- القدرة: صياغة رد مخصص; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-conversation-team.
- Source/Prompt references: server/routers-ai-suggestions.ts:191.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: true; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: require_manual_reply; timeout: 25000 ms.

## sari.reply.improve

- القدرة: تحسين رد مكتوب; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-conversation-team.
- Source/Prompt references: server/routers-ai-suggestions.ts:245.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: true; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: retain_original_reply; timeout: 25000 ms.

## sari.platform.health

- القدرة: فحص اتصال منصة ساري; الحالة: existing; المالك في الكود (غير اعتماد بشري): sari-platform-team.
- Source/Prompt references: server/routers-ai-settings.ts:193.
- التنفيذ: sync; المزود: ZahyPi /v1/jobs عند تفعيله؛ الحالة الحية غير مفحوصة.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: false; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: governed_compatibility; fallback: report_gateway_unavailable; timeout: 15000 ms.

## sari.conversations.analyze

- القدرة: تحليل المحادثة بالكامل; الحالة: planned; المالك في الكود (غير اعتماد بشري): sari-insights-team.
- Source/Prompt references: planned: ZahyPi specialized endpoint /v1/sari/conversations/analyze.
- التنفيذ: async; المزود: مخطط فقط.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: false; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: planned; fallback: continue_live_chat_without_analysis; timeout: 60000 ms.

## sari.outcome

- القدرة: تسجيل نتيجة الإجراء; الحالة: planned; المالك في الكود (غير اعتماد بشري): sari-sales-team.
- Source/Prompt references: planned: ZahyPi specialized endpoint /v1/sari/outcome.
- التنفيذ: sync; المزود: مخطط فقط.
- Actor / Permission / UI trigger / Storage / KPI / SLA: UNKNOWN — OWNER_DECISION_REQUIRED. لا يستنتج الإذن من اسم المهمة.
- Human review في الكتالوج: false; Tenant: Trusted Sari request context; merchant:<id> header. IDs are not authorization..
- Side effects: المخرج يعاد إلى caller داخل Sari؛ إرسال الرسالة/تحديث السجل يخضع لحواجزه، وليس صلاحية تمنحها الحزمة.
- Migration: planned; fallback: queue_outcome_for_retry; timeout: 15000 ms.
