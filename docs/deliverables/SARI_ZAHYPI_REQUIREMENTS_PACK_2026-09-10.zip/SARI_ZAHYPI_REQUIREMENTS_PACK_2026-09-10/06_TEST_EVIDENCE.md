# أدلة الاختبار الفعلية

Source SHA: `3ddfb4d37aa249b10b592c8ca7c435c509264a96`. الحالة المحلية: PASS_WITH_SKIP.

النتيجة الآلية المختصرة في test-evidence/local-gates.json. الاستجابات والاتصالات mocked؛ لا بيانات عميل أو أسرار في المرفق.

المغطى محليًا: مخططات جميع المهام، الحدود، tenant/task/trace، wrong/missing identity، رفض output، توقيع/replay الموصل، المهلات وسياسات المزود، وبوابات الإصدار.

غير مثبت: E2E حي، wrong-key/scope على خادم ZahyPi الحقيقي، آثار الرسائل/الدفع الحية، MySQL integration، جودة النموذج أمام حقن prompt، queue/DLQ، الحمل، Shadow/Canary أو SHA منشور.

Golden cases مرشحات متنوعة لفحص المخطط وليست نتائج تقييم نموذج.
