# قرارات وفجوات الاعتماد

UNKNOWN — OWNER_DECISION_REQUIRED

- تعيين مالك فعلي ونائب لكل مهمة؛ أسماء teams في الكود ليست اعتمادًا.
- UI/actor/permission/storage/side-effect acceptance لكل caller.
- تكلفة/حصة/SLA/KPI، الاحتفاظ والحذف والموافقات؛ أهلية التدريب false حتى تفويض مستقل.
- مقارنة العقد الدلالي لـAction selector بمحرك Next Best Action القاعدي؛ aliases الحالية موثقة ولا تبرر خلط المخرجين.
- دلالة applicationResponse المتوافقة تحتاج مراجعة لكل مهمة؛ schema لا تثبت صحة إجراء تجاري أو مراجعة بشرية فعلية.
- conversations.analyze وoutcome planned، ولا تنفذ أو تعطل live chat من هذه الحزمة.
- حدود الصوت/embeddings والمزود الخارجي، والـDomain Pack commerce.sales والأدوات المقروءة؛ يلزم قرار اعتماد.
- Pilot tasks/tenants، Shadow/Canary ونسبها، مسؤول rollback/incidents، وإثبات الترحيلات والنشر.
