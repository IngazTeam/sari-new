# خريطة الواجهة — حدود الإثبات

السلسلة المثبتة بعد caller: task-catalog → buildSariBusinessInput → /v1/jobs → task-validation → caller.

لا يمنح هذا الربط صلاحية وصول. يلزم اعتماد route والزر/الحدث وactor/permission وحالات loading/success/failure/review لكل مهمة قبل اعتماد الحزمة؛ الحقل ui_surface في الكتالوج يبين ذلك صراحة.

المسارات المرجعية التي يلزم إعادة اختبارها: Test Sari، المحادثات، اقتراحات الرد، تحليل الموقع، إعدادات AI، وأحداث قنوات واتساب. لا تسجّل تجربة واجهة ناجحة دون تشغيلها.
