# العقود الحالية وحدودها

- current text endpoint: /v1/jobs؛ /v1/sari/* مقترح فقط، وليس مسار التنفيذ الحالي.
- المدخل يحوي promptMessages موثوقة من caller؛ لا توجد هنا هجرة مكتملة إلى حقول أعمال مخصصة لكل عملية.
- applicationResponse جسر توافق إلى parsers الحالية؛ المخطط مغلق ومطبق، لكنه لا يثبت المعنى أو ينفذ human review بذاته.
- sari.action.selection وsari.next-action aliases لـsari.sales.next-best-action في الكتالوج الحالي. server/ai/next-best-action.ts محرك قواعد مستقل؛ لا يُزعم تطابق كل أنواع أفعاله مع selector.
- server/websiteAnalysis.ts deprecated وخارج imports الإنتاج بحسب حارس الحوكمة.
- transcription: server/_core/voiceTranscription.ts وserver/voice-transcription.ts؛ embeddings: server/ai/rag-engine.ts؛ تتطلب قرار egress منفصلًا ولا تتحول لمهام نص تلقائيًا.
- لا توجد أمثلة عملاء أو نسخ prompts خام؛ المراجع والبصمات في SOURCE_PROVENANCE.json.
