# لقطة النظام

- Source SHA: `77b76c4d665b630ff733b4aab43e7f69d9914248`; repository: IngazTeam/sari-new; branch: main.
- مؤكد من الكود: TypeScript/React/Express/MySQL/Drizzle؛ Node المطلوب 22.17.1 وpnpm 10.4.1.
- النص والقرارات: /v1/jobs بغلاف input.messages وbusiness_input، ثم poll ومعرفات tenant/task/trace/run_manifest وschema validation.
- merchant:<trusted-id> من سياق الخادم؛ conversationId الحالي في غلاف التوافق مشتق من merchant وليس إثبات ملكية محادثة بعينها.
- قنوات الكود: Meta Cloud وGreen API؛ حالات التشغيل والتوصيل الحالية: UNKNOWN — OWNER_DECISION_REQUIRED.
- voice/embeddings تبقى خارج كتالوج مهام النص؛ انظر current-ai-contracts/CURRENT_BOUNDARIES.md.
- علم البيئة ZAHYPI_ENABLED وإعدادات الإدارة والموصل تحدد المسار؛ لا نفترض قيمة منشورة.
- QA/Production SHA، الترحيلات المطبقة، أحجام الذروة، queues/DLQ وlatency/cost الحية: UNKNOWN — OWNER_DECISION_REQUIRED.
- نجاح البيتا المذكور من المالك: 3 تجار، نحو 100 عميل شهريًا لكل متجر؛ ليس اختبار حمل أو دراسة حالة منشورة.
